import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb, kDebugMode;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'dart:async';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'login_screen.dart';
import 'dashboard_screen.dart';
import 'theme.dart';
import 'splash_screen.dart';
import 'mock_euthereumservice.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize error handlers first
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    debugPrint('🚨 Flutter error caught by onError: ${details.exception}');
    debugPrint('${details.stack}');
  };

  await runZonedGuarded(() async {
    // Load environment variables
    try {
      await dotenv.load(fileName: ".env");
    } catch (e) {
      debugPrint("⚠️ Could not load .env file: $e");
      rethrow;
    }

    // Initialize Firebase
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    // --- Initialize App Check early (before any Firestore/Storage/Functions calls) ---
    // Android: use Debug during development (register the token in Firebase Console) and
    // Play Integrity in release. Web: use reCAPTCHA v3 (site key from .env).
    //
    // .env should contain:
    // FIREBASE_RECAPTCHA_V3_SITE_KEY=your_recaptcha_v3_site_key_here
    final recaptchaSiteKey = dotenv.env['FIREBASE_RECAPTCHA_V3_SITE_KEY'] ?? '';

    await FirebaseAppCheck.instance.activate(
      androidProvider:
          kDebugMode ? AndroidProvider.debug : AndroidProvider.playIntegrity,
      appleProvider: AppleProvider.appAttestWithDeviceCheckFallback,
      webProvider: kIsWeb && recaptchaSiteKey.isNotEmpty
          ? ReCaptchaV3Provider(recaptchaSiteKey)
          : null, // safe no-op if not web or key missing
    );

    // Optional: ensure tokens refresh automatically
    await FirebaseAppCheck.instance.setTokenAutoRefreshEnabled(true);

    // (Optional but nice) Set auth UI language to remove the locale warning
    try {
      await FirebaseAuth.instance.setLanguageCode('en');
    } catch (_) {
      // ignore if not supported on this platform
    }
    // --- End App Check init ---

    final mockService = MockEthereumService();

    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: mockService),
        ],
        child: const LandLedgerApp(),
      ),
    );
  }, (error, stackTrace) {
    debugPrint('🚨 Uncaught zone error: $error');
    debugPrint('$stackTrace');
  });
}

class RouteConstants {
  static const String splash = '/splash';
  static const String login = '/login';
  static const String dashboard = '/dashboard';
}

class LandLedgerApp extends StatelessWidget {
  const LandLedgerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LandLedger',
      debugShowCheckedModeBanner: false,
      theme: buildDarkTheme(),
      initialRoute: RouteConstants.splash,
      routes: {
        RouteConstants.splash: (context) => const SplashScreenWrapper(),
        RouteConstants.login: (context) => const LoginScreen(),
        RouteConstants.dashboard: (context) => DashboardScreen(
              regionId: 'default_region',
              geojsonPath: 'assets/geojson/default.json',
            ),
      },
      builder: (context, child) {
        // Handle render errors gracefully
        ErrorWidget.builder = (FlutterErrorDetails errorDetails) {
          return Material(
            child: Container(
              color: Colors.red[100],
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: Colors.red),
                    const SizedBox(height: 16),
                    const Text(
                      'Something went wrong',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Error: ${errorDetails.exception}',
                      style: const TextStyle(fontSize: 12),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          );
        };

        return FocusTraversalGroup(
          policy: WidgetOrderTraversalPolicy(),
          child: child!,
        );
      },
    );
  }
}

class SplashScreenWrapper extends StatefulWidget {
  const SplashScreenWrapper({super.key});

  @override
  State<SplashScreenWrapper> createState() => _SplashScreenWrapperState();
}

class _SplashScreenWrapperState extends State<SplashScreenWrapper> {
  StreamSubscription<User?>? _sub;

  @override
  void initState() {
    super.initState();
    _checkAuthState();
  }

  Future<void> _checkAuthState() async {
    await Future.delayed(const Duration(seconds: 2));

    _sub = FirebaseAuth.instance.authStateChanges().listen((User? user) {
      if (!mounted) return;
      Navigator.of(context).pushReplacementNamed(
        user == null ? RouteConstants.login : RouteConstants.dashboard,
      );
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const SplashScreen();
  }
}

class RouteGuard {
  static String? redirect(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final route = ModalRoute.of(context)?.settings.name;

    if (user == null && route != RouteConstants.login) {
      return RouteConstants.login;
    }

    if (user != null && route == RouteConstants.login) {
      return RouteConstants.dashboard;
    }

    return null;
  }
}
