import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'comments_screen.dart';
import 'hashtag_utils.dart' as tags;
import 'widgets/responsive_text.dart';

class HomeScreen extends StatefulWidget {
  final String? currentRegionId;
  final String? initialSelectedId;
  final void Function(String regionId, String geojsonPath)? onRegionSelected;
  final VoidCallback? onGoToMap;

  const HomeScreen({
    super.key,
    this.currentRegionId,
    this.initialSelectedId,
    this.onRegionSelected,
    this.onGoToMap,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  // ------- Regions available (ADM1 assets exist for these) -------
  late final List<Map<String, String>> _regions = const [
    {"id": "united_states", "label": "United Stateof America", "path": "assets/data/united_states.geojson"},
    {"id": "cameroon", "label": "Cameroon", "path": "assets/data/cameroon.geojson"},
    {"id": "ghana", "label": "Ghana", "path": "assets/data/ghana.geojson"},
    {"id": "kenya", "label": "Kenya", "path": "assets/data/kenya.geojson"},
    {"id": "nigeria", "label": "Nigeria", "path": "assets/data/nigeria.geojson"},
  ];

  // ISO/name -> region id mapping for "Locate me"
  final Map<String, String> _countryToRegionId = const {
    'US': 'united_states', 'USA': 'united_states', 'united_states': 'united_states',
    'CM': 'cameroon', 'cameroon': 'cameroon',
    'GH': 'ghana',    'ghana': 'ghana',
    'KE': 'kenya',    'kenya': 'kenya',
    'NG': 'nigeria',  'nigeria': 'nigeria',
  };

  final User? _user = FirebaseAuth.instance.currentUser;
  final ImagePicker _picker = ImagePicker();

  String? _selectedRegionId;
  bool _bootstrapped = false;

  // ------- Persistence keys -------
  static const String _prefsRegionKey = 'selected_region_id';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _bootstrapRegionSelection();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // ------- Bootstrap selection (local -> incoming -> remote) -------
  Future<void> _bootstrapRegionSelection() async {
    try {
      final savedLocal = await _readRegionFromLocal();

      // app-supplied preference (optional)
      final incoming = widget.initialSelectedId ?? widget.currentRegionId;

      // choose first valid among [local, incoming]
      String? resolved = [savedLocal, incoming].firstWhere(
        (id) => id != null && _isValidRegion(id),
        orElse: () => null,
      );

      // if none yet, try remote (user setting)
      if (resolved == null) {
        final remote = await _readRegionFromRemote();
        if (remote != null && _isValidRegion(remote)) {
          resolved = remote;
          await _persistRegionLocally(remote); // cache for faster next startup
        }
      } else {
        // we already have one; if signed-in and remote differs, sync it
        final remote = await _readRegionFromRemote();
        if (_user?.uid != null &&
            remote != resolved &&
            _isValidRegion(resolved)) {
          await _persistRegionRemote(resolved);
        }
      }

      if (resolved != null && mounted) {
        _applyRegion(resolved, notifyParent: true, persist: false); // already persisted above
      }
    } catch (e) {
      debugPrint('Region bootstrap error: $e');
    } finally {
      if (mounted) setState(() => _bootstrapped = true);
    }
  }

  bool _isValidRegion(String id) => _regions.any((r) => r['id'] == id);

  // ------- Persistence helpers -------
  Future<void> _persistRegionLocally(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsRegionKey, id);
  }

  Future<String?> _readRegionFromLocal() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_prefsRegionKey);
  }

  Future<void> _persistRegionRemote(String id) async {
    final uid = _user?.uid;
    if (uid == null) return;
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .set({'settings': {'selectedRegionId': id}}, SetOptions(merge: true));
  }

  Future<String?> _readRegionFromRemote() async {
    final uid = _user?.uid;
    if (uid == null) return null;
    final snap = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    return (snap.data()?['settings']?['selectedRegionId'] as String?);
  }

  // ------- Selection API (UI + notify) -------
  void _applyRegion(String regionId, {bool notifyParent = true, bool persist = true}) {
    if (!_isValidRegion(regionId)) return;

    setState(() => _selectedRegionId = regionId);

    if (persist) {
      _persistRegionLocally(regionId);
      _persistRegionRemote(regionId); // noop if signed-out
    }
    if (notifyParent) _notifyRegionSelected(regionId);
  }

  void _notifyRegionSelected(String regionId) {
    final match = _regions.firstWhere((r) => r['id'] == regionId);
    // Defer to avoid "setState during build" errors in parents.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      widget.onRegionSelected?.call(regionId, match['path']!);
    });
  }

  // ------- Locate me -------
  Future<void> _locateMe() async {
    try {
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        perm = await Geolocator.requestPermission();
        if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
          if (!mounted) return;
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('Location permission denied')));
          return;
        }
      }

      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
      final placemarks = await placemarkFromCoordinates(pos.latitude, pos.longitude);
      if (placemarks.isEmpty) {
        if (!mounted) return;
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Could not determine your country')));
        return;
      }

      final p = placemarks.first;
      final iso = (p.isoCountryCode ?? '').toUpperCase();
      final name = (p.country ?? '').toLowerCase();
      final regionId = _countryToRegionId[iso] ?? _countryToRegionId[name];

      if (regionId == null || !_isValidRegion(regionId)) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Your country is not supported yet: ${p.country ?? iso}')),
        );
        return;
      }

      _applyRegion(regionId); // persists + notifies
    } catch (e) {
      debugPrint('Locate me error: $e');
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Failed to locate. Select from dropdown.')));
    }
  }

  // ------- Posts actions -------
  void _toggleLike(String postId, List<String> likedBy) {
    if (_user == null || _selectedRegionId == null) return;
    try {
      final isLiked = likedBy.contains(_user.uid);
      FirebaseFirestore.instance
          .collection('regions')
          .doc(_selectedRegionId)
          .collection('posts')
          .doc(postId)
          .update({
        'likes': FieldValue.increment(isLiked ? -1 : 1),
        'likedBy': isLiked
            ? FieldValue.arrayRemove([_user.uid])
            : FieldValue.arrayUnion([_user.uid]),
      });
    } catch (e) {
      debugPrint('Error toggling like: $e');
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Failed to update like')));
    }
  }

  void _deletePost(BuildContext context, String regionId, String postId) {
    showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Post'),
        content: const Text('Are you sure you want to delete this post?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    ).then((ok) async {
      if (ok != true) return;
      try {
        await FirebaseFirestore.instance
            .collection('regions')
            .doc(regionId)
            .collection('posts')
            .doc(postId)
            .delete();
        if (!mounted) return;
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Post deleted')));
      } catch (e) {
        debugPrint('Error deleting post: $e');
        if (!mounted) return;
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Failed to delete post: $e')));
      }
    });
  }

  void _showCommentsSheet(String postId) {
    if (_selectedRegionId == null) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => CommentSheet(
        postId: postId,
        regionId: _selectedRegionId!,
        user: _user,
      ),
    );
  }

  // ------- Image upload for posts -------
  Future<String?> _uploadImage(XFile file) async {
    try {
      final ref = FirebaseStorage.instance
          .ref('post_images/${DateTime.now().millisecondsSinceEpoch}_${file.name}');
      await ref.putFile(File(file.path));
      return await ref.getDownloadURL();
    } catch (e) {
      debugPrint('Upload error: $e');
      return null;
    }
  }

  void _showNewPostModal() {
    if (_selectedRegionId == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Pick a region first')));
      return;
    }

    final TextEditingController controller = TextEditingController();
    String? postType = 'Update';
    List<XFile> images = [];
    bool uploading = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModal) {
            return Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Create New Post',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    TextField(
                      controller: controller,
                      decoration: const InputDecoration(
                        hintText: 'What would you like to share?',
                        border: OutlineInputBorder(),
                      ),
                      minLines: 1,
                      maxLines: 5,
                    ),
                    const SizedBox(height: 12),
                    if (images.isNotEmpty)
                      SizedBox(
                        height: 100,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: images.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (_, i) => Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.file(
                                  File(images[i].path),
                                  width: 120,
                                  height: 100,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 0,
                                child: IconButton(
                                  icon: const Icon(Icons.close, size: 18),
                                  onPressed: () => setModal(() => images.removeAt(i)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.photo_library),
                          onPressed: () async {
                            final picks = await _picker.pickMultiImage();
                            setModal(() => images.addAll(picks));
                          },
                        ),
                        DropdownButton<String>(
                          value: postType,
                          items: const [
                            DropdownMenuItem(value: 'Update', child: Text('Update')),
                            DropdownMenuItem(value: 'Safety Incident', child: Text('Safety Incident')),
                            DropdownMenuItem(value: 'Infrastructure Damage', child: Text('Infrastructure Damage')),
                            DropdownMenuItem(value: 'New Region', child: Text('New Region')),
                          ],
                          onChanged: (v) => setModal(() => postType = v),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    uploading
                        ? const CircularProgressIndicator()
                        : ElevatedButton(
                            onPressed: () async {
                              if (controller.text.trim().isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Please enter some text')),
                                );
                                return;
                              }
                              setModal(() => uploading = true);
                              try {
                                final urls = <String>[];
                                for (final img in images) {
                                  final url = await _uploadImage(img);
                                  if (url != null) urls.add(url);
                                }
                                await FirebaseFirestore.instance
                                    .collection('regions')
                                    .doc(_selectedRegionId)
                                    .collection('posts')
                                    .add({
                                  'userId': _user?.uid,
                                  'userEmail': _user?.email ?? 'Anonymous',
                                  'type': postType,
                                  'description': controller.text.trim(),
                                  'timestamp': FieldValue.serverTimestamp(),
                                  'likes': 0,
                                  'likedBy': [],
                                  'imageUrls': urls,
                                });
                                if (mounted) Navigator.pop(context);
                                if (!mounted) return;
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(const SnackBar(content: Text('Post created')));
                              } catch (e) {
                                debugPrint('Create post error: $e');
                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Failed to create post: $e')),
                                );
                              } finally {
                                if (mounted) setModal(() => uploading = false);
                              }
                            },
                            child: const Text('Post'),
                          ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  List<InlineSpan> _buildTextWithHashtags(String text) {
    // Delegate clickable hashtag rendering to hashtag_utils.dart
    return tags.buildTextWithHashtag(context, text);
  }

  // ------- UI -------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // SINGLE AppBar with dropdown + locate me + avatar
      appBar: AppBar(
        centerTitle: true,
        titleSpacing: 0,
        title: _RegionDropdownInAppBar(
          regions: _regions,
          selected: _selectedRegionId,
          onChanged: (id) => _applyRegion(id),
        ),
        actions: [
          IconButton(
            tooltip: 'Locate me',
            icon: const Icon(Icons.my_location),
            onPressed: _locateMe,
          ),
          if (_user != null)
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: CircleAvatar(
                radius: 16,
                backgroundImage: _user.photoURL != null ? NetworkImage(_user.photoURL!) : null,
                child: _user.photoURL == null ? const Icon(Icons.person, size: 18) : null,
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showNewPostModal,
        tooltip: 'New Post',
        child: const Icon(Icons.post_add),
      ),
      body: !_bootstrapped
          ? const Center(child: CircularProgressIndicator())
          : _selectedRegionId == null
              ? _EmptyPrompt(onLocate: _locateMe)
              : StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('regions')
                      .doc(_selectedRegionId)
                      .collection('posts')
                      .orderBy('timestamp', descending: true)
                      .snapshots()
                      .handleError((e) => debugPrint('Posts stream error: $e')),
                  builder: (ctx, snap) {
                    if (snap.hasError) {
                      return Center(child: Text('Error: ${snap.error}'));
                    }
                    if (!snap.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final docs = snap.data!.docs;
                    if (docs.isEmpty) {
                      return const Center(child: Text('No posts yet.'));
                    }
                    return ListView.builder(
                      itemCount: docs.length,
                      itemBuilder: (context, i) {
                        final postId = docs[i].id;
                        final data = docs[i].data()! as Map<String, dynamic>;
                        final type = (data['type'] as String?) ?? 'Update';
                        final desc = (data['description'] as String?) ?? '';
                        final ts = data['timestamp'] as Timestamp?;
                        final likes = (data['likes'] as int?) ?? 0;
                        final likedBy = List<String>.from(data['likedBy'] ?? []);
                        final isLiked = _user != null && likedBy.contains(_user.uid);
                        final userEmail = (data['userEmail'] as String?) ?? 'Anonymous';
                        final imageUrls = List<String>.from(data['imageUrls'] ?? []);

                        IconData icon;
                        switch (type) {
                          case 'Safety Incident':
                            icon = Icons.warning;
                            break;
                          case 'Infrastructure Damage':
                            icon = Icons.build;
                            break;
                          case 'New Region':
                            icon = Icons.add_location;
                            break;
                          default:
                            icon = Icons.note;
                        }

                        final timeLabel =
                            ts == null ? '' : ts.toDate().toLocal().toString().substring(0, 16);

                        return ResponsiveContainer(
                          child: Card(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            elevation: 2,
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(icon, color: Theme.of(context).primaryColor),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        type,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      timeLabel,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                RichText(
                                  text: TextSpan(
                                    children: _buildTextWithHashtags(desc),
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Theme.of(context).textTheme.bodyMedium?.color ??
                                          Colors.white,
                                    ),
                                  ),
                                ),
                                if (imageUrls.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  SizedBox(
                                    height: 150,
                                    child: ListView.separated(
                                      scrollDirection: Axis.horizontal,
                                      itemCount: imageUrls.length,
                                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                                      itemBuilder: (_, index) => ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: Image.network(
                                          imageUrls[index],
                                          width: 150,
                                          height: 150,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                                const SizedBox(height: 8),
                                Text(
                                  'Posted by: $userEmail',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        IconButton(
                                          icon: Icon(
                                            isLiked ? Icons.favorite : Icons.favorite_border,
                                            color: isLiked ? Colors.red : Colors.grey,
                                            size: 20,
                                          ),
                                          padding: EdgeInsets.zero,
                                          constraints: const BoxConstraints(),
                                          onPressed: () => _toggleLike(postId, likedBy),
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          '$likes',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey.shade700,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        IconButton(
                                          icon: const Icon(Icons.comment, size: 20),
                                          padding: EdgeInsets.zero,
                                          constraints: const BoxConstraints(),
                                          onPressed: () => _showCommentsSheet(postId),
                                        ),
                                        const SizedBox(width: 8),
                                        if (_user?.uid == data['userId'])
                                          IconButton(
                                            icon: const Icon(Icons.delete, size: 20),
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(),
                                            onPressed: () =>
                                                _deletePost(context, _selectedRegionId!, postId),
                                          ),
                                        IconButton(
                                          icon: const Icon(Icons.share, size: 20),
                                          padding: EdgeInsets.zero,
                                          constraints: const BoxConstraints(),
                                          onPressed: () {},
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        );
                      },
                    );
                  },
                ),
    );
  }
}

// --------- Widgets used in AppBar ----------

class _RegionDropdownInAppBar extends StatelessWidget {
  final List<Map<String, String>> regions;
  final String? selected;
  final ValueChanged<String> onChanged;

  const _RegionDropdownInAppBar({
    required this.regions,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final textColor = Theme.of(context).appBarTheme.titleTextStyle?.color ??
        Theme.of(context).colorScheme.onPrimary;

    return DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        value: selected,
        hint: ResponsiveText('Select a region', style: TextStyle(color: textColor), maxLines: 1),
        isDense: true,
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
        items: regions.map((r) {
          return DropdownMenuItem<String>(
            value: r['id'],
            child: Row(
              children: [
                _Flag(r['id']!),
                const SizedBox(width: 8),
                ResponsiveText(r['label']!, style: TextStyle(color: textColor), maxLines: 1),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _Flag extends StatelessWidget {
  final String id;
  const _Flag(this.id);

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/flags/${id}_flag.png',
      width: 26,
      height: 16,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        width: 26,
        height: 16,
        color: Colors.grey,
        child: const Icon(Icons.flag, size: 12, color: Colors.white),
      ),
    );
  }
}

// --------- Empty state ---------

class _EmptyPrompt extends StatelessWidget {
  final VoidCallback onLocate;
  const _EmptyPrompt({required this.onLocate});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.public, size: 64, color: Colors.grey),
            const SizedBox(height: 12),
            const Text('Choose a region to get started'),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: onLocate,
              icon: const Icon(Icons.my_location),
              label: const Text('Locate me'),
            ),
            const SizedBox(height: 8),
            const Text(
              'Or pick from the dropdown above.',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
