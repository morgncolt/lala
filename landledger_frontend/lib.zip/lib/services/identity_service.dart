// lib/services/identity_service.dart
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'api_client.dart';

String canonicalLabel({
  String? firebaseUid,
  String? username,
  String? email,
}) {
  if (firebaseUid != null && firebaseUid.isNotEmpty) return firebaseUid;
  if (username != null && username.isNotEmpty) return username.trim();
  if (email != null && email.isNotEmpty) return email.toLowerCase().trim();
  throw StateError('No user identifier available');
}

final _store = const FlutterSecureStorage();
final api = Api();

Future<String> ensureIdentityForCurrentUser({
  String? firebaseUid,
  required String email,
  String? username,
}) async {
  final label = canonicalLabel(firebaseUid: firebaseUid, username: username, email: email);
  final cacheKey = 'displayAddress:$label';
  final cached = await _store.read(key: cacheKey);
  if (cached != null && cached.isNotEmpty) return cached;

  final reg = await api.registerIdentity(uid: label, email: email);
  if (reg['ok'] != true) {
    throw Exception('Register failed (${reg['status']}): ${reg['error'] ?? reg}');
  }
  final display = reg['displayAddress'] as String;

  // Don't block UX if link fails (just log server-side)
  await api.linkIdentity(
    uid: label,
    displayAddress: display,
    fingerprint: reg['fingerprint'] as String?,
    mspId: reg['mspId'] as String?,
  );

  await _store.write(key: cacheKey, value: display);
  return display;
}

Future<String?> getCurrentUserWallet() async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) return null;
  final label = canonicalLabel(firebaseUid: user.uid);
  return _store.read(key: 'displayAddress:$label');
}

class IdentityService {
  Future<String?> getDisplayAddress(String label) => _store.read(key: 'displayAddress:$label');
}