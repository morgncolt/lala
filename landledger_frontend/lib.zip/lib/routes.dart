// routes.dart
class RouteConstants {
  static const String splash = '/splash';
  static const String login = '/login';
  static const String dashboard = '/dashboard';
}